<?php

/**
 * Global Helper Functions for siCare System
 */

if (!function_exists('app')) {
    /**
     * Resolve a service from the DI Container.
     *
     * @param string|null $abstract
     * @return mixed|\App\Config\Container
     */
    function app($abstract = null) {
        if ($abstract === null) {
            return \App\Config\Container::getInstance();
        }
        return \App\Config\Container::getInstance()->get($abstract);
    }
}

if (!function_exists('e')) {
    /**
     * Escape HTML entities to prevent XSS attacks.
     *
     * @param string|null $value
     * @return string
     */
    function e($value) {
        return htmlspecialchars($value ?? '', ENT_QUOTES, 'UTF-8');
    }
}

if (!function_exists('csrf_token')) {
    /**
     * Retrieve or generate CSRF token in session.
     *
     * @return string
     */
    function csrf_token() {
        if (session_status() === PHP_SESSION_NONE && !headers_sent() && PHP_SAPI !== 'cli') {
            session_start();
        }
        if (empty($_SESSION['csrf_token'])) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        }
        return $_SESSION['csrf_token'];
    }
}

if (!function_exists('csrfField')) {
    /**
     * Generate HTML hidden input field for CSRF token (camelCase).
     *
     * @return string
     */
    function csrfField() {
        return '<input type="hidden" name="csrf_token" value="' . htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8') . '">';
    }
}

if (!function_exists('csrf_field')) {
    /**
     * Generate HTML hidden input field for CSRF token (snake_case).
     *
     * @return string
     */
    function csrf_field() {
        return csrfField();
    }
}

if (!function_exists('db_query')) {
    /**
     * Helper to execute SQL queries using prepared statements dynamically.
     * Prevents raw string interpolation in database operations.
     *
     * @param string $sql
     * @param array $params
     * @return PDOStatement
     */
    function db_query($sql, $params = []) {
        $db = \App\Config\Database::getInstance()->getConnection();
        if (empty($params)) {
            return $db->query($sql);
        }
        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        return $stmt;
    }
}

if (!function_exists('validate_password_strength')) {
    /**
     * Validate password strength based on configured global settings.
     *
     * @param string $password
     * @param string &$errorMsg
     * @return bool
     */
    function validate_password_strength($password, &$errorMsg) {
        $db = \App\Config\Database::getInstance()->getConnection();
        
        // Fetch security settings
        $stmt = $db->query("SELECT `key`, `value` FROM global_settings WHERE `key` IN ('min_password_length', 'require_uppercase', 'require_number', 'require_special_char')");
        $rules = [];
        while ($row = $stmt->fetch(\PDO::FETCH_ASSOC)) {
            $rules[$row['key']] = $row['value'];
        }

        $minLen = (int)($rules['min_password_length'] ?? 8);
        $reqUpper = ($rules['require_uppercase'] ?? 'false') === 'true';
        $reqNum = ($rules['require_number'] ?? 'false') === 'true';
        $reqSpecial = ($rules['require_special_char'] ?? 'false') === 'true';

        if (strlen($password) < $minLen) {
            $errorMsg = "Kata sandi minimal harus {$minLen} karakter.";
            return false;
        }

        if ($reqUpper && !preg_match('/[A-Z]/', $password)) {
            $errorMsg = "Kata sandi wajib mengandung setidaknya satu huruf kapital.";
            return false;
        }

        if ($reqNum && !preg_match('/[0-9]/', $password)) {
            $errorMsg = "Kata sandi wajib mengandung setidaknya satu angka.";
            return false;
        }

        if ($reqSpecial && !preg_match('/[^a-zA-Z0-9]/', $password)) {
            $errorMsg = "Kata sandi wajib mengandung setidaknya satu karakter spesial.";
            return false;
        }

        return true;
    }
}

if (!function_exists('resolveProfilePicture')) {
    /**
     * Menentukan URL gambar profil pengguna dengan cascade:
     * 1. Google profile picture (jika ada/diberikan)
     * 2. Gravatar custom profile picture (jika diset untuk email tersebut)
     * 3. Fallback MD5 Gravatar biasa (Mystery Person)
     *
     * @param string $email
     * @param string|null $googlePic
     * @return string
     */
    function resolveProfilePicture($email, $googlePic = null) {
        if (!empty($googlePic)) {
            return $googlePic;
        }
        
        $h = md5(strtolower(trim($email)));
        $gravatarUrl = "https://www.gravatar.com/avatar/{$h}?d=404";
        
        // Lakukan HEAD request cepat ke Gravatar
        $ch = curl_init($gravatarUrl);
        curl_setopt($ch, CURLOPT_NOBODY, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 2);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 2);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_exec($ch);
        $statusCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($statusCode === 200) {
            return "https://www.gravatar.com/avatar/{$h}";
        }
        
        // Kembalikan null jika tidak ada kustom Gravatar maupun Google profile
        return null;
    }
}

if (!function_exists('validate_and_format_phone')) {
    /**
     * Validate and format phone number.
     * Rules:
     * - Must be pure digits (no spaces, no other characters).
     * - Length must be 10 to 14 digits.
     * - If starts with '08', automatically converts to '628'.
     * - If starts with '628', remains '628'.
     * 
     * @param string $phone
     * @param string &$errorMsg
     * @return string|bool Formatted phone number on success, false on failure.
     */
    function validate_and_format_phone($phone, &$errorMsg) {
        // Enforce pure digits (no spaces, no characters)
        // Note: we check the original raw string without trim to ensure no leading/trailing spaces
        if (!preg_match('/^[0-9]+$/', $phone)) {
            $errorMsg = "Nomor telepon harus berupa angka murni tanpa spasi atau karakter lain.";
            return false;
        }

        $length = strlen($phone);
        if ($length < 10 || $length > 14) {
            $errorMsg = "Nomor telepon harus terdiri dari minimal 10 digit dan maksimal 14 digit.";
            return false;
        }

        if (str_starts_with($phone, '08')) {
            return '628' . substr($phone, 2);
        }

        return $phone;
    }
}

if (!function_exists('format_duration_minutes')) {
    /**
     * Format minute duration according to rules:
     * - <= 0 minutes -> "0 menit"
     * - <= 60 minutes -> "X menit" (e.g. "60 menit", "45 menit")
     * - > 60 minutes -> "X jam Y menit" (e.g. "1 jam 30 menit") or "X jam" if Y == 0
     *
     * @param int|float|string $minutes
     * @return string
     */
    function format_duration_minutes($minutes): string {
        $mins = max(0, (int)$minutes);
        if ($mins <= 60) {
            return "{$mins} menit";
        }
        $h = (int)floor($mins / 60);
        $m = $mins % 60;
        if ($m === 0) {
            return "{$h} jam";
        }
        return "{$h} jam {$m} menit";
    }
}

